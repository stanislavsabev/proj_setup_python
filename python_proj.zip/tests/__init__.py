"""Tests for python_proj package"""
