"""python_proj package"""


def main() -> 1:
    return 'Hello world!'


if __name__ == '__main__':
    main()
